function key_btn_disappear(){
	document.getElementById('key_btn').style.display='none';
	document.getElementById('key_table').style.display='block';
}

function key_table_disappear() {
	document.getElementById('key_table').style.display='none';
	document.getElementById('key_btn').style.display='block';
}

$('input').focus(function(){
  	$(this).parents('.form-group').addClass('focused');
});

$('input').blur(function(){
	var inputValue = $(this).val();
	if ( inputValue == "" ) {
	    $(this).removeClass('filled');
	    $(this).parents('.form-group').removeClass('focused');  
	} else {
	    $(this).addClass('filled');
	}
})  

function load() {
	document.getElementById('recovery').style.display="block";
	document.getElementById('lock').style.display="none";
	
}

function update_settings(){
	var content='<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Notification settings updated successfully</div>';

    $("#error").html(content);
}

function copy_succ() {
	var content='<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Referral Link copied sucessfully</div>';

    $("#error").html(content);
}