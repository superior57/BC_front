

$(document).ready(function(){
	$("#myCarousel").carousel();
    
  
  // Enable Carousel Controls
	$(".left").click(function(){
	    $("#myCarousel").carousel("prev");
	});
	$(".right").click(function(){
	    $("#myCarousel").carousel("next");
	});


	var flag=0;
	if(flag==0) {
		flag=1;
		var elem = document.getElementById("myBar");
		var length = 5;
		var id = setInterval(frame, 300);
		function frame() {
			if(length>=100) {
				clearInterval(id);
				m=0;
				setTimeout(complete,2000);
				function complete(){
					window.location.href="installComplete.html";
					
				}
			} else {
				length+=1;
				elem.style.width=length+"%";
				$("#progress_text").text(length+"%");
			}
		}
	}



  	$("#carosel_1_head").delay(1000).fadeIn();
	$("#carousel_1_para1").delay(1200).fadeIn();
	$("#carousel_1_para2").delay(1400).fadeIn();
	$("#carousel_1_para3").delay(1600).fadeIn();
	$("#carousel_1_para4").delay(1800).fadeIn();
	$("#carousel_1_para5").delay(2000).fadeIn();

	
	$("#carousel_1_img").delay(2300).animate({top:'50px'},800)


	var i=1;
	$("#myCarousel").on('slid.bs.carousel', function () {
	  	i++;
	  	if (i==6) {i=1;}
		for(j=1;j<=5;j++){
			$("#carosel_"+j+"_head").css("display","none");
	  		$("#carousel_"+j+"_para1").css("display","none");
	  		$("#carousel_"+j+"_para2").css("display","none");
	  		$("#carousel_"+j+"_para3").css("display","none");
	  		$("#carousel_"+j+"_para4").css("display","none");
	  		$("#carousel_"+j+"_para5").css("display","none");
	  		$("#carousel_"+j+"_img").css("top","500px");

	  	}

		$("#carosel_"+i+"_head").delay(1000).fadeIn();
		$("#carousel_"+i+"_para1").delay(1200).fadeIn();
		$("#carousel_"+i+"_para2").delay(1400).fadeIn();
		$("#carousel_"+i+"_para3").delay(1600).fadeIn();
		$("#carousel_"+i+"_para4").delay(1800).fadeIn();
		$("#carousel_"+i+"_para5").delay(2000).fadeIn();
		
		$("#carousel_"+i+"_img").delay(2300).animate({top:'50px'},800)

	});

	$(".left").click(function(){

		i-=2;
		if(i==-1){i=4;}
	});


});