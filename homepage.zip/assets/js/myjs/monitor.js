$(function(){
    $('.select2').select2()

//Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
})

function addToMonitoring(){
	var content='<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Enter IP address or Pubkey of your masternode</div>';

    $("#error").html(content);
}