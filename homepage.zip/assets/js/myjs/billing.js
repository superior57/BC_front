$(function(){
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
})

$("#pay_select").change(function(){
    var i = $("#pay_select").val();
    
    var content="<img src='assets/images/payment_images/"+i+".png' style='width:100px;height:100px;'>";
    $("#pay_image").html(content);
})

$("#amount").keyup(function(){
    val=$("#amount").val();
    $("#amount_money").text(val);
})

function make_payment() {
    var content='<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please enter valid amount</div>';

    $("#error").html(content);
}