$("#close_btn").click(function(){
	document.getElementById("accept").checked=false;
	document.getElementById("alarm").innerHTML='';
})

$("#continue_btn").click(function() {
	if(document.getElementById('accept').checked==false){
		var content="<div class='alert alert-danger alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Warning please accept our Terms of Service</div>";
    	$("#alarm_1").html(content);
	} else {
		$("#panel_1").css('display','none');
		$("#panel_2").css('display','block');
		$("#close_btn").css('display','none');
		$("#back_btn").css('display','inline');
		$("#continue_btn").css('display','none');
		$("#add_btn").css('display','inline');
		$("#alarm_1").html("");
	}
})

$("#back_btn").click(function() {
	$("#panel_1").css('display','block');
	$("#panel_2").css('display','none');
	$("#close_btn").css('display','inline');
	$("#back_btn").css('display','none');
	$("#continue_btn").css('display','inline');
	$("#add_btn").css('display','none');

	$("#server_label").val('');
	$("#vps_password").val('');
	$("#vps_ip").val('');

	document.getElementById("accept").checked=false;
	$("#alarm_2").html("");
	
})

$("#add_btn").click(function() {
	var content="<div class='alert alert-danger alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Warning please fillout All required fields</div>";
	var server_label=document.getElementById('server_label').value;
	var vps_ip=document.getElementById('vps_ip').value;
	var vps_password=document.getElementById('vps_password').value;
	
	if((server_label=='')||(vps_ip=='')||(vps_password=='')) {
		$("#alarm_2").html(content);
	}else{
		$("#myModal").modal('hide');
		$("#alarm_2").html("");
		$("#panel_1").css('display','block');
		$("#panel_2").css('display','none');
		document.getElementById("accept").checked=false;
		$("#close_btn").css('display','inline');
		$("#back_btn").css('display','none');
		$("#continue_btn").css('display','inline');
		$("#add_btn").css('display','none');
	}	
})