$(document).ready(function(){
  	$('[data-toggle="tooltip"]').tooltip(); 
  	var elem=document.getElementsByClassName("mo");[0];  
  	elem[0].style.backgroundColor='grey';
  	elem[1].style.backgroundColor='white';
  	elem[2].style.backgroundColor='white';
});

$(".edit_icon").click(function() {
	$()
})

function show_edit_1() {
	$("#check_1").css("display","block");
	$("#edit_1").hide();
}

function check_icon_1() {
	$("#check_1").css("display","none");
	$("#edit_1").css("display","block");
	var content="<div class='alert alert-danger alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Don't use the same txhash</div>";

    $("#error").html(content);
}

function cancel_icon_1(){
	$("#check_1").css("display","none");
	$("#edit_1").css("display","block");
}

function show_edit_2() {
	$("#check_2").css("display","block");
	$("#edit_2").hide();
}

function check_icon_2() {
	$("#check_2").css("display","none");
	$("#edit_2").css("display","block");
	var content="<div class='alert alert-success alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>RewardAddress updated successfully</div>";

    $("#error").html(content);
}

function cancel_icon_2(){
	$("#check_2").css("display","none");
	$("#edit_2").css("display","block");
}

function show_edit_3() {
	$("#check_3").css("display","block");
	$("#edit_3").hide();
}

function check_icon_3() {
	$("#check_3").css("display","none");
	$("#edit_3").css("display","block");
	var content="<div class='alert alert-success alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>ownerAddress updated successfully</div>";

    $("#error").html(content);
}

function cancel_icon_3(){
	$("#check_3").css("display","none");
	$("#edit_3").css("display","block");
}

function show_edit_4() {
	$("#check_4").css("display","block");
	$("#edit_4").hide();
}

function check_icon_4() {
	$("#check_4").css("display","none");
	$("#edit_4").css("display","block");
	var content="<div class='alert alert-success alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>feesourceaddress updated successfully</div>";

    $("#error").html(content);
}

function cancel_icon_4(){
	$("#check_4").css("display","none");
	$("#edit_4").css("display","block");
}

function copy_success() {
	var content="<div class='alert alert-success alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Copied sucessfully</div>";

    $("#error").html(content);
}

var color='';

$(".mo").mouseover(function(){
	color=$(this).css('background-color');
	$(this).css('background-color','lightgrey');
})

$(".mo").mouseout(function(){
	$(this).css('background-color',color);
})

$(".mo").click(function(){
	var content="<div class='alert alert-success alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Your masternode plan updated successfully</div>";

    $("#error").html(content);
})

$("#toggle_btn").click(function() {
	var content="<div class='alert alert-success alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Your masternode auto renew plan updated successfully</div>";
    $("#error").html(content);
    margin=$('#white_circle').css('margin-left');
    if(margin=='8px'){
    	$("#check_con").css('display','none');
    	$("#white_circle").css('margin-left','2px');
    	$("#close_con").css('display','block');
    	$("#toggle_btn").css('background-color','lightgrey');
    } else{
    	$("#check_con").css('display','block');
    	$("#white_circle").css('margin-left','8px');
    	$("#close_con").css('display','none');
    	$("#toggle_btn").css('background-color','#1890ff');
    }
    
})

$("#long_btn_con").click(function() {
	var content="<div class='alert alert-success alert-dismissible'><a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Copied sucessfully</div>";
    $("#error").html(content);
})

$("#node").mouseover(function(){
	$("#edit_0").css('display','inline');
})

$("#node").mouseout(function(){
	$("#edit_0").css('display','none');
})

function show_edit_0(){
	$("#node").css("display",'none');
	$("#check_0").css("display",'block');
}

function check_icon_0(){
	$("#check_0").css("display",'none');
	$("#node").css("display",'block');
	$("#edit_0").css('display','none');
}

function cancel_icon_0(){
	$("#check_0").css("display",'none');
	$("#node").css("display",'block');
	$("#edit_0").css('display','none');
}

$(function () {
    $('.select2').select2()
})