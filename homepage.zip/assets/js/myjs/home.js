var k=1;
for (var k = 1; k <=3; k++) {
    $('#input'+String(k)).focus(function(){
        $(this).parents('.form-group').addClass('focused');
    });

    $('#input'+String(k)).blur(function(){
        var inputValue = $(this).val();
        if ( inputValue == "" ) {
            $(this).removeClass('filled');
            $(this).parents('.form-group').removeClass('focused');  
        } else {
            $(this).addClass('filled');
        }
    })  
}


$(function(){
    $('.select2').select2()

    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
});

var i=1,j=1;

function next() {
    if(i==3) {
        j++;
        $("#panel"+j).slideDown("fast");
        $("#panel"+(j-1)).slideUp("fast");
        i--;
        if (j==5) {
            $("#create_btn").css("display","block");
            $("#continue_btn").css("display","none");
        }
    }
    i++;
    
    $("#div"+i).slideDown("fast");
    $("#div"+(i-1)).slideUp("fast");
}

function back() {
    if(i==3) {
        j--;
        i++;
        if (j==4) {
            $("#create_btn").css("display","none");
            $("#continue_btn").css("display","block");
        }
        if(j==0){i=3;j=1;}
        $("#panel"+j).slideDown("fast");
        $("#panel"+(j+1)).slideUp("fast");
    }
    i--;
    if(i==0){i=1;}
    $("#div"+i).slideDown("fast");
    $("#div"+(i+1)).slideUp("fast");
}

$("#verifyModalContent").on("hidden.bs.modal", function() {
    $("#div"+i).slideUp("fast");
    $("#div1").slideDown("fast");
    i=1;
    $("#panel"+j).slideUp("fast");
    $("#panel1").slideDown("fast");
    j=1;
    $("#create_btn").css("display","none");
    $("#continue_btn").css("display","block");
})